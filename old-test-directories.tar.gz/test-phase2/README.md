# Terraform Integration SDK - Phase 2 Testing

This directory contains test configurations for Phase 2 features of the Integration SDK.

## Phase 2 Features Being Tested

1. **Operation Control**: Integrations can now fail operations (not just warn)
2. **Multiple Hooks**: Pre-plan-resource, post-plan-resource, pre-apply-resource, plan-stage-complete
3. **Policy Enforcement**: The policy validator can prevent non-compliant resources
4. **Budget Control**: The budget checker can halt operations that exceed limits
5. **Provider-scoped Integrations**: (Configuration syntax is ready, implementation pending)

## Test Scenarios

### 1. Policy Validation

The configuration includes several resources that will trigger policy violations:

- `random_integer.invalid_port`: max = 100 (fails: > 10)
- `random_integer.medium_number`: max = 20 (fails: > 10)
- `random_string.too_short`: length = 5 (fails: < 8)
- `random_string.too_long`: length = 64 (fails: > 32)
- `random_password.weak_password`: special = false (fails: no special chars)

### 2. Budget Checking

The budget checker is configured with:
- Monthly budget: $500
- Max single resource: $100

All test resources have $0 cost, so budget checks should pass.

## Running the Tests

### 1. Build the Phase 2 Terraform

```bash
cd /path/to/terraform_claude_agent
export PATH=$PWD/go/bin:$PATH
go build -o terraform-integration
```

### 2. Test Policy Failures

```bash
cd test-phase2
../terraform-integration init

# This should FAIL due to policy violations
TF_LOG=INFO ../terraform-integration plan
```

Expected output:
- Policy validator will report violations for resources exceeding limits
- The plan operation should be halted by the integration
- You'll see error messages about policy violations

### 3. Test with Compliant Configuration

To see a successful run, comment out the non-compliant resources:

```hcl
# Comment out these resources in main.tf:
# - random_integer.invalid_port
# - random_integer.medium_number  
# - random_string.too_short
# - random_string.too_long
# - random_password.weak_password
```

Then run:
```bash
TF_LOG=INFO ../terraform-integration plan
```

This should succeed with all policies passing.

### 4. Test Apply-time Enforcement

If you manage to create a plan (with compliant resources), try to apply:

```bash
TF_LOG=INFO ../terraform-integration apply
```

The integrations will:
1. Run pre-apply checks
2. Enforce policies one more time
3. Complete apply-stage-complete hooks

## Understanding the Output

### Integration Initialization
```
[INFO] Initialized integration "policy_validator": version=1.0.0, hooks=[pre-plan-resource post-plan-resource pre-apply-resource plan-stage-complete]
```

### Policy Violations
```
[ERROR] Integration policy_validator failed in post-plan-resource: Policy violations detected: Maximum value 100 exceeds policy limit of 10
```

### Operation Halted
```
Error: Plan operation halted by integration

An integration has halted the plan operation.
```

## Debugging

To see detailed integration communication:
```bash
TF_LOG=DEBUG ../terraform-integration plan 2>&1 | grep -E "(Integration|policy|budget)"
```

To see only stderr output from integrations:
```bash
TF_LOG=INFO ../terraform-integration plan 2>&1 | grep "stderr:"
```

## Phase 2 vs Phase 1

Key differences from Phase 1:
- ❌ Phase 1: Integrations could only log and warn
- ✅ Phase 2: Integrations can FAIL operations
- ❌ Phase 1: Only post-plan-resource hook
- ✅ Phase 2: Multiple hooks throughout the lifecycle (resource-level and operation-level)
- ❌ Phase 1: No real control
- ✅ Phase 2: Policy enforcement, budget control, operation halting

## Next Steps

To implement provider-scoped integrations:
1. Update IntegrationManager to handle provider-specific integrations
2. Filter resources by provider before calling hooks
3. Test with provider-specific policies